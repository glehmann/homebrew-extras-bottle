var classtlp_1_1_double_algorithm =
[
    [ "DoubleAlgorithm", "classtlp_1_1_double_algorithm.html#ab39eeb22a62043656fd9eb6cb89175aa", null ],
    [ "category", "classtlp_1_1_double_algorithm.html#a21ee2b030db5ffd50f95159ea29aec27", null ]
];