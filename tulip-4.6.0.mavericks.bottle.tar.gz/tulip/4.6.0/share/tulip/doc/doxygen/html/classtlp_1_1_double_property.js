var classtlp_1_1_double_property =
[
    [ "PredefinedMetaValueCalculator", "group___graph.html#ga92554034c68f7c84511a58d1441996b8", [
      [ "NO_CALC", "group___graph.html#gga92554034c68f7c84511a58d1441996b8ab888a1a659e3dd243aa50109f5f0c1c0", null ],
      [ "AVG_CALC", "group___graph.html#gga92554034c68f7c84511a58d1441996b8a928c4b7971b93d048c8a2dfdc2da120f", null ],
      [ "SUM_CALC", "group___graph.html#gga92554034c68f7c84511a58d1441996b8ab477553d770d7176dcd3b3ac51601623", null ],
      [ "MAX_CALC", "group___graph.html#gga92554034c68f7c84511a58d1441996b8aeff67450e3a2b91c347a107b7a10556d", null ],
      [ "MIN_CALC", "group___graph.html#gga92554034c68f7c84511a58d1441996b8a941acf7ebec7851ef9fae57d0192837d", null ]
    ] ],
    [ "DoubleProperty", "classtlp_1_1_double_property.html#aa284e5e4a9afded166812a727b69f3ae", null ],
    [ "clone_handler", "classtlp_1_1_double_property.html#ac0b23a184f8b126085dec663b1391399", null ],
    [ "clonePrototype", "classtlp_1_1_double_property.html#a5d05d4d8e8b392eabd221dacf0c743b6", null ],
    [ "copyProperty", "classtlp_1_1_double_property.html#a9c3e70bfd57b4a75dbe0b1d614dee40c", null ],
    [ "edgesUniformQuantification", "classtlp_1_1_double_property.html#a948faf1626d4001ea4e16e9197f360ae", null ],
    [ "getEdgeDoubleDefaultValue", "classtlp_1_1_double_property.html#ade950506ffdf8f1bea27615c33f004e7", null ],
    [ "getEdgeDoubleMax", "classtlp_1_1_double_property.html#a5f7a8a380851f76fc9fc7201a3f256c0", null ],
    [ "getEdgeDoubleMin", "classtlp_1_1_double_property.html#a3f7fdd93633189fb1e631ccb617b8e7d", null ],
    [ "getEdgeDoubleValue", "classtlp_1_1_double_property.html#ac9a48261621e89081b69e889d1cc82bf", null ],
    [ "getNodeDoubleDefaultValue", "classtlp_1_1_double_property.html#abd5a9e2ff2b7956d177a815eabbde5a4", null ],
    [ "getNodeDoubleMax", "classtlp_1_1_double_property.html#afc9b0982a2382a3ae46f7752a755e4a4", null ],
    [ "getNodeDoubleMin", "classtlp_1_1_double_property.html#ae5fbb379ba4423af55969518fb64c742", null ],
    [ "getNodeDoubleValue", "classtlp_1_1_double_property.html#a64a8f2a1cbd65200e26dc87fc96df20f", null ],
    [ "getTypename", "classtlp_1_1_double_property.html#a6cdfddb97547c489fd29052fc3548653", null ],
    [ "nodesUniformQuantification", "classtlp_1_1_double_property.html#a96b4418a832a66a21c075bf4b4075d5d", null ],
    [ "setAllEdgeValue", "classtlp_1_1_double_property.html#a02f92c04467cb093e69ad9a1002be7f7", null ],
    [ "setAllNodeValue", "classtlp_1_1_double_property.html#aee318539281b031ef6948a16fbf655f7", null ],
    [ "setEdgeValue", "classtlp_1_1_double_property.html#a6955fc59c5cce149eb81a8dfee6f95f7", null ],
    [ "setMetaValueCalculator", "classtlp_1_1_double_property.html#a45e5ae73f3b26203a4e4992cf2d16fe2", null ],
    [ "setMetaValueCalculator", "classtlp_1_1_double_property.html#a57470573ed766909467a0d967d09e266", null ],
    [ "setNodeValue", "classtlp_1_1_double_property.html#a634236ab4ca1185c1aece33e863aa4cd", null ],
    [ "propertyTypename", "classtlp_1_1_double_property.html#ab8a9a64dc3307d328a6403f4ecfced88", null ]
];