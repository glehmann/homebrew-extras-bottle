var classtlp_1_1_color_algorithm =
[
    [ "ColorAlgorithm", "classtlp_1_1_color_algorithm.html#a64b27f8abeda32cb7de63cd48aba7c03", null ],
    [ "category", "classtlp_1_1_color_algorithm.html#adf9b62c49ef15a3687c5f623056f36a7", null ]
];