var classtlp_1_1_gl_default_selection_color_manager =
[
    [ "defaultSelectionColor", "classtlp_1_1_gl_default_selection_color_manager.html#a5a967de1457b790da0a0330dbe6e826f", null ],
    [ "getDefaultSelectionColor", "classtlp_1_1_gl_default_selection_color_manager.html#a2b6acfd10f55e17fe0b10289ca984ebe", null ],
    [ "setManager", "classtlp_1_1_gl_default_selection_color_manager.html#ad830755f9d8186c7dd13a5e7f14cdb1f", null ]
];