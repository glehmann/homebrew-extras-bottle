var classtlp_1_1_gl_circle =
[
    [ "GlCircle", "classtlp_1_1_gl_circle.html#afb85d6a6edce9ec53f34a7b1407ce7b3", null ],
    [ "getXML", "classtlp_1_1_gl_circle.html#a857284bfcb4cfff6ae264af781cd3290", null ],
    [ "set", "classtlp_1_1_gl_circle.html#a712cbbeca87efc1d3a0d26fdcdfa8046", null ]
];