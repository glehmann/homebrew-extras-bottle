var classtlp_1_1_gl_triangle =
[
    [ "GlTriangle", "classtlp_1_1_gl_triangle.html#a4f7e59b350dede8a046464749a3e1c51", null ],
    [ "~GlTriangle", "classtlp_1_1_gl_triangle.html#aadf654f024f96fc4ea511362f74a0e7d", null ]
];