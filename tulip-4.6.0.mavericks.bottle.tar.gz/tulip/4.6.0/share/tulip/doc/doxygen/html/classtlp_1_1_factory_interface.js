var classtlp_1_1_factory_interface =
[
    [ "createPluginObject", "classtlp_1_1_factory_interface.html#a68727c92028b31d206a3128d56858284", null ]
];