var classtlp_1_1_boolean_algorithm =
[
    [ "BooleanAlgorithm", "classtlp_1_1_boolean_algorithm.html#adae0b7592e802784f4e017d0d28a2f78", null ],
    [ "category", "classtlp_1_1_boolean_algorithm.html#aea1ca3fd2d289e17e6d451340eea454f", null ]
];