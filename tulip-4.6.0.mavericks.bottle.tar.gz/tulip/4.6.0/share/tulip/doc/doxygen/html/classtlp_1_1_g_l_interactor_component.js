var classtlp_1_1_g_l_interactor_component =
[
    [ "compute", "classtlp_1_1_g_l_interactor_component.html#ab2b232fb8576acfb542273108397b7c4", null ],
    [ "draw", "classtlp_1_1_g_l_interactor_component.html#a31e76c1517d255c5e01e0d5b1d812657", null ]
];