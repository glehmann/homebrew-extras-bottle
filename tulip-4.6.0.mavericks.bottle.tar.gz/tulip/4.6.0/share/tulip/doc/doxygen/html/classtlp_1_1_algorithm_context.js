var classtlp_1_1_algorithm_context =
[
    [ "AlgorithmContext", "classtlp_1_1_algorithm_context.html#a51c3f6650ad5cd9eec8b350012086126", null ],
    [ "~AlgorithmContext", "classtlp_1_1_algorithm_context.html#a5c2cba4e062f51dc1816de15726cca23", null ],
    [ "dataSet", "classtlp_1_1_algorithm_context.html#a8295e7dfb7054fa75505a5590b8df7bf", null ],
    [ "graph", "classtlp_1_1_algorithm_context.html#aad8eff8ddf71cc085bd8240ea2f75077", null ],
    [ "pluginProgress", "classtlp_1_1_algorithm_context.html#a757d00cbf56c751c8b56a7daead59281", null ]
];