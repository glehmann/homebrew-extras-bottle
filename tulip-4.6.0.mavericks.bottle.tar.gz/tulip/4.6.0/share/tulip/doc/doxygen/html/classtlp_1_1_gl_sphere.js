var classtlp_1_1_gl_sphere =
[
    [ "GlSphere", "classtlp_1_1_gl_sphere.html#a8c00fcb16d2743a4249d6a475ad9c87a", null ],
    [ "GlSphere", "classtlp_1_1_gl_sphere.html#a945c92fdf7d11314afdc371f477a2fb0", null ],
    [ "GlSphere", "classtlp_1_1_gl_sphere.html#a893e273674d9f6c7267373ddc74f34a2", null ],
    [ "draw", "classtlp_1_1_gl_sphere.html#a0e88b5bcd0c08afc6bf8cdfa9c0acc7c", null ],
    [ "getColor", "classtlp_1_1_gl_sphere.html#a4867a4fceb30b917127bb1c345be0d14", null ],
    [ "getPosition", "classtlp_1_1_gl_sphere.html#ad6fdf38eb7f8eb83042205d36bc222ad", null ],
    [ "getXML", "classtlp_1_1_gl_sphere.html#abbf5dc2d52b24f0dfc97d91c42980907", null ],
    [ "setColor", "classtlp_1_1_gl_sphere.html#aa0864d3e96f1e540243275a97a13afdd", null ],
    [ "setPosition", "classtlp_1_1_gl_sphere.html#aaa4ffed33d580273bb23d44522944009", null ],
    [ "setTexture", "classtlp_1_1_gl_sphere.html#a7fe78b1e5911ea455aa3a9e7b1ec07c6", null ],
    [ "setWithXML", "classtlp_1_1_gl_sphere.html#ae02e15759ab6a411627a2808e0198abe", null ],
    [ "translate", "classtlp_1_1_gl_sphere.html#a38d75c505db59afe08dfa546a36201e4", null ]
];