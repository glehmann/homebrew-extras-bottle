These are QtCreator wizards to quickly create the boilerplate code for a new plugin or tulip executable.

For them to show un in QtCreator, all you have to do is copy these folders into the correct path.

* Linux
	/usr/share/qtcreator/templates/wizards/
* Windows 
	C:\QtSDK\QtCreator\share\qtcreator\templates\wizards